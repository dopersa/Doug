package br.com.universidade.implementacao;

import br.com.universidade.modelo.Aluno;
import br.com.universidade.modelo.Curso;
import br.com.universidade.modelo.Endereco;
import br.com.universidade.modelo.Filial;
import br.com.universidade.modelo.Turma;
import br.com.universidade.tela.Magica;

public class ImplementarTurma {

	public static void main(String[] args) {
		Turma t = new Turma(
				Magica.t("ID"),
				Magica.t("Periodo"),
				new Curso(
						Magica.t("Desc"),
						Magica.t("Forma"),
						Magica.d("$"),
						Magica.i("CH")
						),
				new Filial(
						Magica.i("N�"),
						Magica.t("Nome"),
						Magica.t("Fone"),
						new Endereco(
								Magica.t("Logradouro"),
								Magica.t("Bairro"),
								Magica.t("Cidade"),
								Magica.t("UF"),
								Magica.t("CEP"),
								Magica.t("Complemento"),
								Magica.t("Numero")
								)
						),
				new Aluno(
						Magica.t("Nome"),
						Magica.i("Matricula"),
						Magica.t("Email")
						)
				);
		
		System.out.println(t.getPeriodo());
		System.out.println(t.getAluno().getNome());
		System.out.println(t.getCurso().getDescricao());
		System.out.println(t.getFilial().getNome());
		System.out.println(t.getFilial().getEndereco().getCidade());
		
		// OU (Podemos criar antes e preencher depois)
		//Curso curso = new Curso();
		//Filial filial = new Filial();
		//Aluno aluno = new Aluno();
		//Turma t2 = new Turma("","", curso, filial, aluno);
		//curso.setDescricao("");
		
	}

}
