package br.com.universidade.implementacao;

import javax.swing.JOptionPane;

import br.com.universidade.modelo.AlunoTeste;
import br.com.universidade.tela.Magica;

public class Teste {

	public static void main(String[] args) {
		// Somente criando o objeto
		//Aluno objeto;
		
		// Criar e instanciar o objeto
		AlunoTeste objeto = new AlunoTeste();
		objeto.preencherNome(JOptionPane.showInputDialog("Digite o nome"));
		objeto.preencherEmail(JOptionPane.showInputDialog("Email:"));
		objeto.preencherNumeroMatricula(Integer.parseInt
										(JOptionPane.showInputDialog("Matricula")));
		System.out.println("Nome.....: " + objeto.exibirNome());
		System.out.println("Email....: " + objeto.exibirEmail());
		System.out.println("Matr�cula: " + objeto.exibirNumeroMatricula());

		
		
	}

}
