package br.com.universidade.implementacao;

import br.com.universidade.modelo.Curso;
import br.com.universidade.tela.Magica;

public class ImplementarCurso {
	
	public static void main(String[] args) {
		Curso curso = new Curso();
		
		curso.setDescricao(Magica.t("Descri��o"));
		curso.setFormacao(Magica.t("Formacao"));
		curso.setValor(Magica.d("Valor"));
		curso.setCargaHoraria(Magica.i("Carga"));
		
		System.out.println(curso.getDescricao() + "\n" + curso.getFormacao() + 
				"\n" + curso.getValor() + "\n" + curso.getCargaHoraria());

		
	}

}
