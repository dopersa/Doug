package br.com.universidade.implementacao;

import javax.swing.JOptionPane;

import br.com.universidade.modelo.AlunoTeste;

public class Teste4 {

	public static void main(String[] args) {
	
		AlunoTeste objeto = new AlunoTeste(
				JOptionPane.showInputDialog("Nome:"), 
				Integer.parseInt(JOptionPane.showInputDialog("Matricula")), 
				JOptionPane.showInputDialog("Email")
				);
		System.out.println(objeto.exibirTudo());
		
		
		
		
	}

}
