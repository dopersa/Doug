package br.com.universidade.implementacao;

import br.com.universidade.modelo.Endereco;
import br.com.universidade.modelo.Filial;
import br.com.universidade.tela.Magica;

public class ImplementarFilial2 {

	public static void main(String[] args) {

		Filial filial = new Filial(
				Magica.i("N�mero da Filial"),
				Magica.t("Nome da Filial"),
				Magica.t("Telefone da Filial"),
				new Endereco(
						Magica.t("Logradouro"),
						Magica.t("Bairro"),
						Magica.t("Cidade"),
						Magica.t("Estado"),
						Magica.t("CEP"),
						Magica.t("Complemento"),
						Magica.t("Numero")
						)
				);

		System.out.println(filial.getNome());
		System.out.println(filial.getFone());
		System.out.println(filial.getEndereco().getBairro());
		System.out.println(filial.getEndereco().getCidade());
		
	}

}
