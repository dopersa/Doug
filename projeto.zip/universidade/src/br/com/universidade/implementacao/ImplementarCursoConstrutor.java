package br.com.universidade.implementacao;

import br.com.universidade.modelo.Curso;
import br.com.universidade.tela.Magica;

public class ImplementarCursoConstrutor {

	public static void main(String[] args) {
		Curso curso = new Curso(
				Magica.t("Desc"),
				Magica.t("For"),
				Magica.d("Valor"),
				Magica.i("Carga")
				);
		System.out.println(curso.getDescricao() + "\n" + curso.getFormacao() + 
				"\n" + curso.getValor() + "\n" + curso.getCargaHoraria());
	}

}
