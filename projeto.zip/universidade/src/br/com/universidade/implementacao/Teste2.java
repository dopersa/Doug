package br.com.universidade.implementacao;

import javax.swing.JOptionPane;

import br.com.universidade.modelo.AlunoTeste;

public class Teste2 {

	public static void main(String[] args) {
	
		AlunoTeste objeto = new AlunoTeste();
		objeto.preencherTudo(
				JOptionPane.showInputDialog("Digite o nome"), 
				Integer.parseInt(JOptionPane.showInputDialog("Digite a matricula")), 
				JOptionPane.showInputDialog("Email")
				);
		System.out.println("Nome.....: " + objeto.exibirNome());
		System.out.println("Email....: " + objeto.exibirEmail());
		System.out.println("Matr�cula: " + objeto.exibirNumeroMatricula());
		
		
		
	}

}
