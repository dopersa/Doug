package br.com.universidade.tela;

import javax.swing.JOptionPane;

public class Magica {
	
	public static String t(String msg) {
		return JOptionPane.showInputDialog(msg).toUpperCase();
	}
	
	public static double d(String msg) {
		return Double.parseDouble(t(msg));
	}
	
	public static int i(String msg) {
		return Integer.parseInt(t(msg));
	}
	
}
