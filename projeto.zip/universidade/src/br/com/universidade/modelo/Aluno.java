package br.com.universidade.modelo;

public class Aluno {
	private String nome;
	private int numeroMatricula;
	private String email;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getNumeroMatricula() {
		return numeroMatricula;
	}
	public void setNumeroMatricula(int numeroMatricula) {
		this.numeroMatricula = numeroMatricula;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Aluno(String nome, int numeroMatricula, String email) {
		super();
		this.nome = nome;
		this.numeroMatricula = numeroMatricula;
		this.email = email;
	}
	public Aluno() {
		super();
		nome = new String();
		email = new String();
	}

	
	
}
