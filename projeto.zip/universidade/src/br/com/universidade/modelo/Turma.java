package br.com.universidade.modelo;

public class Turma {
	private String identificador;
	private String periodo;
	private Curso curso;
	private Filial filial;
	private Aluno aluno;
	public Turma() {
		identificador = new String();
		periodo = new String();
		curso = new Curso();
		filial = new Filial();
		aluno = new Aluno();
	}
	public Turma(String identificador, String periodo, Curso curso, Filial filial, Aluno aluno) {
		super();
		this.identificador = identificador;
		this.periodo = periodo;
		this.curso = curso;
		this.filial = filial;
		this.aluno = aluno;
	}
	public String getIdentificador() {
		return identificador;
	}
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	public String getPeriodo() {
		return periodo;
	}
	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}
	public Curso getCurso() {
		return curso;
	}
	public void setCurso(Curso curso) {
		this.curso = curso;
	}
	public Filial getFilial() {
		return filial;
	}
	public void setFilial(Filial filial) {
		this.filial = filial;
	}
	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}

}
