package br.com.universidade.modelo;

public class Filial {
	private int numero;
	private String nome;
	private String fone;
	private Endereco endereco;
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getFone() {
		return fone;
	}
	public void setFone(String fone) {
		this.fone = fone;
	}
	public Endereco getEndereco() {
		return endereco;
	}
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	public Filial() {
		nome = new String();
		fone = new String();
		endereco = new Endereco();
	}
	public Filial(int numero, String nome, String fone, Endereco endereco) {
		super();
		this.numero = numero;
		this.nome = nome;
		this.fone = fone;
		this.endereco = endereco;
	}

}
