package br.com.universidade.modelo;
/*
 * Beans (Design Pattern)
 * Regras:
 * 1� TODOS os atributos devem ser privados
 * 2� TODOS os atributos devem ter um getter e um setter (individual) no m�nimo.
 * 3� DEVE ter no MINIMO dois construtores (vazio e cheio)
 */
public class Curso {

	private String descricao;
	private String formacao;
	private double valor;
	private int cargaHoraria;
	
	/* Sintaxe de um m�todo construtor:
	 * <modificador> <nomedaClasse>(<param1>,...<param>)
	 */

	public Curso() {
		descricao = new String();
		formacao = new String();
	}
	public Curso(String descricao, String formacao, double valor, int cargaHoraria) {
		super();
		this.descricao = descricao;
		this.formacao = formacao;
		this.valor = valor;
		this.cargaHoraria = cargaHoraria;
	}
	
	/* Sintaxe de um m�todo get/set:
	 * <modificador> <retorno> <nomeMetodo>(<param1>,...<param>)
	 * Exemplos:
	 * public        void      setValor(double pValor) => m�todo setter 
	 * public        double    getValor() 			   => m�todo getter
	 */
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao.toUpperCase();
	}
	public String getFormacao() {
		return formacao;
	}
	public void setFormacao(String formacao) {
		this.formacao = formacao;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public int getCargaHoraria() {
		return cargaHoraria;
	}
	public void setCargaHoraria(int cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}
	
}


