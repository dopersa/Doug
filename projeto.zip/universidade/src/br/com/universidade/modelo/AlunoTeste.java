package br.com.universidade.modelo;


public class AlunoTeste {
	
	//Todo Beans deve ter:
	// * atributos privados
	// * um input(preencher) e output(exibir) individual para cada atributo
	// * deve ter no m�nimo dois construtores: um vazio e um cheio
	
	private String nome;
	private int numeroMatricula;
	private String email;
	
	public AlunoTeste(String pNome, int pNumeroMatricula, String pEmail) {
		preencherNome(pNome);
		preencherNumeroMatricula(pNumeroMatricula);
		preencherEmail(pEmail);
	}
	
	public AlunoTeste() {
		nome = new String();
		email = new String();
	}
	
	public String exibirTudo() {
		return exibirNome() + "\n" + numeroMatricula + "\n" + email;
	}
	
	public void preencherTudo(String pNome, int pNumeroMatricula, String pEmail) {
		preencherNome(pNome);
		preencherNumeroMatricula(pNumeroMatricula);
		preencherEmail(pEmail);
	}
	
	public void preencherNumeroMatricula(int pNumeroMatricula) {
		if (pNumeroMatricula>0) {
			numeroMatricula=pNumeroMatricula;
		}
	}
	
	public int exibirNumeroMatricula() {
		return numeroMatricula;
	}
	
	public void preencherEmail(String pEmail) {
		if (pEmail.indexOf("@")>=0 && pEmail.length()<70) {
			email=pEmail;
		}
	}
	
	public String exibirEmail() {
		return email;
	}
	
	public String exibirNome() {
		return nome;
	}
	
	public void preencherNome(String pNome) {
		if (pNome.length()>5 && pNome.length()<50) {
			nome=pNome.toUpperCase();
		}else {
			nome="Nome inv�lido";
		}
	}
	

}
